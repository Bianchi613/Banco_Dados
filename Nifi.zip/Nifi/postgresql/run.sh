#!/bin/bash

function populate(){
    docker exec postgresql-postgres-compose-1 psql -U postgres -d 'postgres' -p 5432 -c "$(cat ./populate_primary_db.sql)";
}

function seed(){
    docker exec postgresql-postgres-compose-1 psql -U postgres -d 'postgres' -p 5432 -c "$(cat ./populate_primary_db2.sql)";
}

$1